package com.unla.grupo16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Grupo16ApplicationTests {

	@Test
	void contextLoads() {
	}

}
