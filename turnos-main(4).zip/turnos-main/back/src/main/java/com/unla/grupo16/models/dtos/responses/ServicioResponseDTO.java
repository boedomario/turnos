package com.unla.grupo16.models.dtos.responses;

public record ServicioResponseDTO(
        Integer id,
        String nombre,
        String descripcion,
        int duracion
        ) {

}

// OK
