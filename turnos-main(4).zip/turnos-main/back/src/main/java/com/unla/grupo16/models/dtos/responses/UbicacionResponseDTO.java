package com.unla.grupo16.models.dtos.responses;

public record UbicacionResponseDTO(
        Integer id,
        String direccion,
        String localidad
        ) {

}

// OK
