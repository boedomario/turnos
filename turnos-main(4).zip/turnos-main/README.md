back : mvn spring-boot:run
front : npm start

configurar aplication.yml con db,user root, pw root, email y código 